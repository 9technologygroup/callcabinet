#!/bin/bash
username=""
DIR=/home/$username
DAEMON_NAME=64bit20221115withlibsu16
DAEMON=$DIR/$DAEMON_NAME


cd $DIR
yes | nohup ./$DAEMON_NAME > $DIR/cc.out 2>&1 &
exit 0
