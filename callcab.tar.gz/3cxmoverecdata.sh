#!/bin/bash

# This script moves and renames the 3CX recordings to a new location with the correct naming convention for the CCmodule to upload to Atmos. See example of 3CX supported recording names below.
# Set the soure directory to read files
# default is /var/lib/3cxpbx/Instance1/Data/Recordings/
username=""

SRCDR="/var/lib/3cxpbx/Instance1/Data/Recordings"

# Set the destination output directory to the CallCabinet respository
DSTDR="/home/$username/recordings"

#spin='-\|/'

OIFS="$IFS"
IFS=$'\n'

   for filename in $(find $SRCDR -type f -mmin +1 -name "*.wav")
do
#  i=$(( (i+1) %4 ))
#  printf "\r Please wait... ${spin:$i:1}"
	movelogs=/home/$username/movelogs
	find /home/$username/movelogs/*.log -mtime +30 -exec rm {} \;
	logdate=$(date +%Y-%m-%d)
	logfile=$movelogs/${logdate}.log
#	echo "$filename" >>./getccrecdata.log
	SRCDST=$(echo $filename | cut -f2 -d_)
#	echo "$SRCDST" >>./getccrecdata.log
	SRC=$(echo $SRCDST | cut -f2 -d-) >>./getccrecdata.log
#	echo "$SRC" >>./getccrecdata.log
	DST=$(echo $SRCDST | cut -f1 -d-) >>./getccrecdata.log
#	echo "$DST" >>./getccrecdata.log
#	CID=$(echo $filename | cut -f6 -d-)
#	CALLID="${CID%.*}"
	  if [ "$DST" -gt "$SRC" ]; then DIR=INCOMING; EXT=$SRC; PHN=$DST
	  else DIR=OUTGOING; EXT=$DST; PHN=$SRC
	  fi
	  if [ -z "$EXT" ]; then EXT=anonymous;
	  fi
	  if [ -z "$PHN" ]; then PHN=anonymous;
	  fi
	DATEF=$(stat -c %y "$filename");
	DATEFO="${DATEF%.*}"
	DATETIME=${DATEFO/ /T}
  	DATE=$DATETIME
	FOLDERS=`date +"%Y/%m/%d"`
	mkdir -p /home/$username/recordings/${FOLDERS}
# Without SubSiteID:
	mv "$filename" $DSTDR/${FOLDERS}/${PHN}_${DATE}_${EXT}_0_${DIR}.WAV
# Example with SubSiteID:
#	mv "$filename" $DSTDR/${FOLDERS}/${PHN}_${DATE}_${EXT}_0_${DIR}_${SUBSITEID}.WAV
	now=$(date +%Y-%m-%d%I:%M:%S)
	echo $now Found new recording and moved file: "$filename" to CallCabinet repository: $DSTDR/${PHN}_${DATE}_${EXT}_0_${DIR}.WAV >> $logfile
done
IFS="$OIFS"
#echo Completed. View movelogs for details

