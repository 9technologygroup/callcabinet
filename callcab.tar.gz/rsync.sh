#!/bin/bash

# Enhanced script to sync files from a server supplying wav files to a CallCabinet Ingestion Server with added checks
username=""
customer_name=""

# Source and destination directories
CAPTUREDIR="/home/$username/recordings"
DSTDIR="/home/$username/recordings/$customer_name"
DSTTMPDIR="/home/$username/recordings/$customer_name/tmp"

# Log file for tracking
LOGFILE="/home/$username/recording_sync.log"

# Function to check network connectivity before initiating sync
check_network_connection() {
    ping -c 1 8.8.8.8 &> /dev/null
    if [ $? -ne 0 ]; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') - Network to CallCabinet server is down" >> $LOGFILE
        return 1
    fi
    return 0
}

# Function to perform rsync
sync_files() {
    for filename in $(find $CAPTUREDIR -mmin +2 -type f -name '*.wav'); do
        rsync -av --temp-dir=$DSTTMPDIR $filename ${DSTDIR} &>> $LOGFILE

        if [ $? -eq 0 ]; then
            echo "Successfully transferred: $filename" >> $LOGFILE
            rm -f $filename
        else
            echo "Failed to transfer: $filename" >> $LOGFILE
        fi
    done
}

# Main execution
echo "$(date '+%Y-%m-%d %H:%M:%S') - Starting recordings sync" >> $LOGFILE
if check_network_connection; then
    sync_files
else
    echo "$(date '+%Y-%m-%d %H:%M:%S') - Sync aborted due to network issues" >> $LOGFILE
fi
